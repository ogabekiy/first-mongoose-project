import Router from "express";
import {
  addBook,
  deleteBook,
  getAllBooks,
  getBookById,
  searchBookByCategory,
  searchBookByTitle,
  searchBookbyAuthor,
  updateBook,
} from "../core/book/book.service.js";

const bookRouter = Router();
bookRouter.post("/add", addBook);
bookRouter.get("/all", getAllBooks);
bookRouter.get("/:id", getBookById);
bookRouter.delete("/delete/:id", deleteBook);
bookRouter.put("/update/:id", updateBook);
bookRouter.get("/search/:title", searchBookByTitle);
bookRouter.get("/searchByCategory/:category", searchBookByCategory);
bookRouter.get("/searchByAuthor/:author", searchBookbyAuthor);
export default bookRouter;
