import { Router } from "express";
import {
  addAuthor,
  deleteAuthor,
  getAllAuthors,
  getAuthorById,
  updateAuthor,
} from "../core/author/author.service.js";

const authorRouter = Router();

authorRouter.post("/add", addAuthor);
authorRouter.get("/all", getAllAuthors);
authorRouter.get("/:id", getAuthorById);
authorRouter.put("/update/:id", updateAuthor);
authorRouter.delete("/delete/:id", deleteAuthor);

export default authorRouter;
