import { Router } from "express";
import {
  addCategory,
  deleteCategoryById,
  getAllCategories,
  getCategoryById,
  updateCategory,
} from "../core/category/category.service.js";

const categoryRouter = Router();
categoryRouter.post("/add", addCategory);
categoryRouter.get("/all", getAllCategories);
categoryRouter.get("/:id", getCategoryById);
categoryRouter.delete("/delete/:id", deleteCategoryById);
categoryRouter.put("/update/:id", updateCategory);
export default categoryRouter;
