import { authorModel } from "./author.model.js";
import { createAuthorValidator } from "./author.validator.js";

export async function addAuthor(req, res) {
  try {
    const newAuthor = req.body;

    const { error } = createAuthorValidator.validate(newAuthor);
    if (error) {
      return res.status(400).send(error.details[0].message);
    }

    console.log(newAuthor);
    const result = await authorModel.create(newAuthor);

    res.status(200).send("Malumot muvaffaqiyatli qo'shildi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Aftor kiritishda xatolik bo'ldi");
  }
}
export async function getAllAuthors(req, res) {
  try {
    const result = await authorModel.find();

    res.status(200).send(result);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Aftorlarni olishda xatolik bo'ldi");
  }
}
export async function getAuthorById(req, res) {
  try {
    const { id } = req.params;

    const result = await authorModel.findById(id);
    res.status(200).send(result);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Aftorni olishda xatolik bo'ldi");
  }
}

export async function updateAuthor(req, res) {
  try {
    const { id } = req.params;
    const newAuthor = req.body;

    const result = await authorModel.findByIdAndUpdate(id, newAuthor);
    res.status(200).send("Aftor muvaffaqiyatli yangilandi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Aftorni yangilashda xatolik bo'ldi");
  }
}

export async function deleteAuthor(req, res) {
  try {
    const { id } = req.params;
    const result = await authorModel.findByIdAndDelete(id);
    res.status(200).send("Aftor muvaffaqiyatli o'chirildi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Aftorni o'chirishda xatolik bo'ldi");
  }
}
