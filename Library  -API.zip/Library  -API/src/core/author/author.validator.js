import Joi from "joi";

export const createAuthorValidator = Joi.object({
  name: Joi.string().required().messages({
    "string.empty": "Ism kirtish shart!!!",
    "string.base": "Ism text Ko'rinishida bo'lish kerak",
  }),
  biography: Joi.string().min(20).required().messages({
    "string.empty": "Biografiyaga malumot kiritishingiz zarur!!",
    "string.base": "Biografiya text Ko'rinishida bo'lish kerak",
    "string.min": "Biografiya kamida 20 ta belgi bo'lishi kerak",
  }),
});
