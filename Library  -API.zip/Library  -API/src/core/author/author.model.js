import mongoose, { Schema } from "mongoose";

const authorSchema = new Schema({
  name: { type: String, require: true },
  biography: { type: String, require: true },
});

export const authorModel = mongoose.model("authors", authorSchema);
