import mongoose, { Schema } from "mongoose";

const bookSchema = new Schema({
  title: { type: String, required: true },
  author_id: { type: Schema.Types.ObjectId, ref: "authors", required: true },
  category_id: {
    type: Schema.Types.ObjectId,
    ref: "categories",
    required: true,
  },
  publishedYear: { type: Number, required: true },
  summary: { type: String, required: true },
});

export const bookModel = mongoose.model("books", bookSchema);
