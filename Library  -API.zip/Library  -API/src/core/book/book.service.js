import { authorModel } from "../author/author.model.js";
import { categoryModel } from "../category/category.model.js";
import { bookModel } from "./book.model.js";

export async function addBook(req, res) {
  try {
    const newBook = req.body;
    const result = await bookModel.create(newBook);
    res.status(200).send("Book muvaffaqiyatli qo'shildi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Book qo'shishda xatolik bo'ldi" + err.message);
  }
}
export async function getAllBooks(req, res) {
  try {
    const result = await bookModel.find();
    res.status(200).send(result);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Hamma kitoblarni olishda xatolik bo'ldi");
  }
}
export async function getBookById(req, res) {
  try {
    const { id } = req.params;

    const result = await bookModel.findById(id);
    res.status(200).send(result);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Id bo'yicha kitob olishda xatolik");
  }
}
export async function deleteBook(req, res) {
  try {
    const { id } = req.params;
    const result = await bookModel.findByIdAndDelete(id);
    res.status(200).send("Kitob muvaffaqiyatli o'chirildi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Kitobni o'chirishda xatolik bo'ldi");
  }
}
export async function updateBook(req, res) {
  try {
    const { id } = req.params;
    const newBook = req.body;

    const result = await bookModel.findByIdAndUpdate(id, newBook);

    res.status(200).send("Kitob Muvaffaqitali yangilandi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Kitobni yangilashda xatolik bo'ldi");
  }
}

// Kitoblarni nomi, muallifi yoki kategoriyasi bo'yicha qidirish imkoniyatini qo'shish.
export async function searchBookByTitle(req, res) {
  try {
    const { title } = req.params;

    const result = await bookModel.find({
      title: { $regex: title, $options: "i" },
    });

    if (result.length === 0) {
      return res.status(404).send("Bunday kitob yoq");
    }

    res.status(200).json(result);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Kitob izlashda xatolik");
  }
}
export async function searchBookByCategory(req, res) {
  try {
    const { category } = req.params;

    // console.log(category);
    const categoryData = await categoryModel.findOne({
      name: { $regex: category, $options: "i" },
    });

    // console.log(categoryData)

    // console.log(categoryData.id);

    const books = await bookModel.find({
      category_id: categoryData.id,
    });
    // console.log(books);
    res.status(200).send(books);
  } catch (err) {
    console.log(err.message);
    res
      .status(500)
      .send("Categoriya boyicha izlashda xatolik boldi: " + err.message);
  }
}
export async function searchBookbyAuthor(req, res) {
  try {
    const { author } = req.params;

    const authorData = await authorModel.findOne({
      name: { $regex: author, $options: "i" },
    });

    const books = await bookModel.find({
      author_id: authorData.id,
    });

    res.status(200).send(books);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Aftor bilan izlashda xatolik boldi");
  }
}
