import Joi from "joi";

export const createBookValidator = Joi.object({
  title: Joi.string().required().messages({
    "string.empty": "Kitob nomi kiritish shart!!!",
    "string.base": "Nom text Ko'rinishida bo'lish kerak",
  }),
  author_id: Joi.string().required(),
  category_id: Joi.string().required(),
  publishedYear: Joi.number().required(),
  summary: Joi.string(),
});
