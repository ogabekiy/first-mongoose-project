import { categoryModel } from "./category.model.js";
import { createCategoryValidator } from "./category.validator.js";

export async function addCategory(req, res) {
  try {
    const newCategory = req.body;

    const result = await categoryModel.create(newCategory);

    res.status(200).send("Categoriya muvaffaqiyatli qo'shildi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Categoriya qo'shishda xatolik bo'ldi");
  }
}
export async function getAllCategories(req, res) {
  try {
    const result = await categoryModel.find();
    res.status(200).send(result);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Categoriyalarni olishda xatolik bo'ldi");
  }
}
export async function getCategoryById(req, res) {
  try {
    const { id } = req.params;
    const result = await categoryModel.findById(id);
    res.status(200).send(result);
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Categoriya olishda xatolik boldi!!!");
  }
}
export async function deleteCategoryById(req, res) {
  try {
    const { id } = req.params;
    const result = await categoryModel.deleteOne({ _id: id });
    res.status(200).send("Catagoriya muvaffaqiyatli o'chirildi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Categoriya o'chirishda xatolik bo'ldi");
  }
}
export async function updateCategory(req, res) {
  try {
    const { id } = req.params;
    const newCategory = req.body;
    const result = await categoryModel.findByIdAndUpdate(id, newCategory);
    res.status(200).send("Categoriya muvaffaqiyatli yangilandi");
  } catch (err) {
    console.log(err.message);
    res.status(500).send("Categoriya yangilashda xatolik bo'ldi" + err.message);
  }
}
