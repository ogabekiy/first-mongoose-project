import Joi from "joi";

export const createCategoryValidator = Joi.object({
  name: Joi.string().required().messages({
    "string.empty": "Nom kirtish shart!!!",
    "string.base": "Nom text Ko'rinishida bo'lish kerak",
  }),
  description: Joi.string().required().messages({
    "string.base": "Biografiya text Ko'rinishida bo'lish kerak",
  }),
});
