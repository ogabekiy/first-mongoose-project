import mongoose, { Schema } from "mongoose";

const categorySchema = new Schema({
  name: { type: String, require: true },
  description: { type: String, require: true },
});

export const categoryModel = mongoose.model("categories", categorySchema);
