import express from "express";
import getConfig from "./common/config/config.service.js";
import initDatabase from "./common/database/database.service.js";
import authorRouter from "./controller/author.controller.js";
import categoryRouter from "./controller/category.controller.js";
import bookRouter from "./controller/book.controller.js";
const app = express();
const PORT = getConfig("EXPRESS_PORT") || 3000;

async function initRoutes() {
  app.use("/author", authorRouter);
  app.use("/category", categoryRouter);
  app.use("/book", bookRouter);
}

async function init() {
  app.use(express.json());
  initDatabase();
  initRoutes();
  app.listen(PORT, () => console.log(`Server ${PORT} PORT da ishlayapti`));
}
init();
